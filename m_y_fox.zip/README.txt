m_y_dork_02 - anthro red fox (game-ready GTA IV files)
=====================================================

Drop-in replacements for the ped's three files:
  m_y_dork_02.wdd   models (modified)
  m_y_dork_02.wtd   textures (modified)

Install (OpenIV): back up the originals, then replace both files in
pc/models/cdimages/componentpeds.img.

What's in them
- head_000_r: fox head with ears merged into the skull, and fox paws with
  claws. High and medium LOD. The jaw still moves with speech.
- uppr_000_r: black tee with fur arms (orange -> dark brown at the paws).
  The wrist cuffs/watch are removed.
- lowr_000_u: jeans and sneakers plus a bushy fox tail on the pelvis,
  coming straight out from the lower back on a diagonal.
- hoodie (uppr_001) and messenger bag (suse_*): untouched.

Texture variants (all in the .wtd):
- head a/b/c: all the fox
- tee a-e: all black (same fur arms)
- jeans a regular, b dark wash
- normal maps are flat; spec maps are low except the nose, eyes and claws.

Known limits
- The tail is rigid on the pelvis (no tail bones). It can clip the legs
  when running and car seats when sitting.
- No blinking.
